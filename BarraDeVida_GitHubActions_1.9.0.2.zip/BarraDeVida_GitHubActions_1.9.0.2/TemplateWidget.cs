using System;
using System.Reflection;
using System.Xml.Linq;
using Engine;

namespace Game {
    // Muestra solamente la vida actual de la última criatura golpeada.
    public class TemplateWidget : CanvasWidget {
        private readonly LabelWidget m_label;

        public TemplateWidget() {
            LoadContents(this, ContentManager.Get<XElement>("Widgets/TemplateWidget"));
            m_label = Children.Find<LabelWidget>("TemplateLabel");
            m_label.Text = "";
        }

        public override void Update() {
            ComponentHealth health = TemplateHarmonyPatch.LastHitHealth;
            if (health == null) {
                m_label.Text = "";
                return;
            }

            try {
                PropertyInfo property = health.GetType().GetProperty("Health", BindingFlags.Instance | BindingFlags.Public);
                object value = property != null ? property.GetValue(health) : null;
                if (value == null) {
                    FieldInfo field = health.GetType().GetField("m_health", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
                    value = field != null ? field.GetValue(health) : null;
                }
                if (value == null) {
                    m_label.Text = "HP";
                } else {
                    float hp = Convert.ToSingle(value);
                    m_label.Text = Math.Max(0f, hp).ToString("0.##") + " HP";
                }
            } catch {
                m_label.Text = "HP";
            }
        }
    }
}
