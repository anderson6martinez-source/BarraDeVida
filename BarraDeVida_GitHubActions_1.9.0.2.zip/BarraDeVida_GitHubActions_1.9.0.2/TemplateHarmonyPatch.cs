using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using GameEntitySystem;
using HarmonyLib;

namespace Game {
    // Captura el cuerpo atacado por el minero del jugador. No cambia el daño.
    [HarmonyPatch]
    internal static class TemplateHarmonyPatch {
        internal static ComponentHealth LastHitHealth;

        static IEnumerable<MethodBase> TargetMethods() {
            return AccessTools.GetDeclaredMethods(typeof(ComponentMiner))
                .Where(method => method.Name == "AttackBody");
        }

        static void Postfix(ComponentMiner __instance, object[] __args) {
            try {
                // Ignora ataques hechos por criaturas u otros mineros que no pertenecen al jugador.
                if (__instance == null || __instance.Entity == null ||
                    __instance.Entity.FindComponent<ComponentPlayer>(true) == null) {
                    return;
                }

                foreach (object argument in __args) {
                    ComponentBody body = argument as ComponentBody;
                    if (body == null || body.Entity == null) continue;
                    ComponentHealth health = body.Entity.FindComponent<ComponentHealth>(true);
                    if (health != null) {
                        LastHitHealth = health;
                        return;
                    }
                }
            } catch {
                // Un fallo de captura no debe interrumpir el ataque normal.
            }
        }
    }
}
