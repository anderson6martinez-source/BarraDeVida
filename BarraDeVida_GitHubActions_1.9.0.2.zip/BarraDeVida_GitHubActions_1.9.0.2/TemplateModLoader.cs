using HarmonyLib;

namespace Game {
    public class TemplateModLoader : ModLoader {
        public const string PackageName = "ander.BarraDeVida";

        public override void __ModInitialize() {
            Harmony harmony = new Harmony(PackageName);
            harmony.PatchAll();
        }
    }
}
