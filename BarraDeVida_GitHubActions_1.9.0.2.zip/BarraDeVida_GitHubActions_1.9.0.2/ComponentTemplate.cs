using Engine;
using GameEntitySystem;
using TemplatesDatabase;

namespace Game {
    // Componente del jugador: añade el texto de vida a la interfaz.
    public class ComponentTemplate : Component, IUpdateable {
        public ComponentPlayer m_componentPlayer;
        private bool m_widgetInserted = false;

        public UpdateOrder UpdateOrder => UpdateOrder.Default;

        public override void Load(ValuesDictionary valuesDictionary, IdToEntityMap idToEntityMap) {
            m_componentPlayer = Entity.FindComponent<ComponentPlayer>(true);
            Log.Information("BarraDeVida: componente del jugador cargado.");
        }

        public void Update(float dt) {
            if (!m_widgetInserted && m_componentPlayer != null && m_componentPlayer.GuiWidget != null) {
                m_componentPlayer.GuiWidget.AddChildren(new TemplateWidget());
                m_widgetInserted = true;
            }
        }
    }
}
