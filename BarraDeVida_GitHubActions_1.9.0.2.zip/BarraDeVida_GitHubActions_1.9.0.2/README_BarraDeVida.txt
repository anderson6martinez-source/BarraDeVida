BARRA DE VIDA - BASE DE CODIGO
API objetivo: 1.9.0.2

Esta carpeta contiene una primera implementación fuente:
- El componente del jugador añade el widget.
- El parche intenta capturar el ComponentBody atacado por ComponentMiner.AttackBody.
- El widget lee la propiedad Health y muestra "N HP".
- El parche no modifica los argumentos ni el resultado del daño.

IMPORTANTE: esto todavía NO es un .scmod compilado ni probado en el juego.
La captura del objetivo usa reflexión sobre AttackBody para tolerar diferencias de firma,
pero hay que compilar contra las DLL de API 1.9.0.2 y probar en Survivalcraft.
Si la API no expone ComponentMiner.Entity, ComponentBody.Entity o la propiedad Health
como se espera, el compilador indicará el miembro que debe ajustarse.
